//
//  PagPay.h
//  PagPay
//
//  Created by Lucas Brito on 11/08/20.
//  Copyright © 2020 PagBank. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PagPay.
FOUNDATION_EXPORT double PagPayVersionNumber;

//! Project version string for PagPay.
FOUNDATION_EXPORT const unsigned char PagPayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PagPay/PublicHeader.h>


